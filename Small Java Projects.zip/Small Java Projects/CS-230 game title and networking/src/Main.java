

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import networkingMOTD.LeaderBoard;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.awt.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javafx.scene.text.*;


/**
 * This class is responsible for creating the main menu.
 * @author Blaine Ramsden
 * @version 1.1
 *
 */

public class Main extends Application{

    private double screenWidth;
    private double screenHeight;
    private Stage window;
    private Scene mainMenu, settings;
    private String inputStream2 = "background2_withCharacters.jpg";
    private Label lTitle, lone, ltwo, lthree, lfour, lfive, lsix, lseven, leight, lnine, lten,  pad1, pad2, pad3, pad4, pad5, lpad1, lpad2;
    private final String L_STYLE = "-fx-font-weight: bold;-fx-text-fill: White;-fx-font-size: 20;";
    private Button playButton, settingsButton, quitButton, tutorialButton, newGameButton, mainCharacter1Button, mainCharacter2Button;
    private GridPane layoutMain;
    private LeaderBoard leaderboard = new LeaderBoard();

    public void play() throws FileNotFoundException {
        HBox layoutPlay = new HBox();
        BackgroundImage myBI= new BackgroundImage(new Image(inputStream2   ,screenWidth,screenHeight,false,true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        layoutPlay.setBackground(new Background(myBI));

        mainCharacter1Button = new Button();
        mainCharacter1Button.setGraphic(new ImageView(new Image("mainCharacter1.png")));
        mainCharacter1Button.setOnAction(e -> System.exit(0));

        mainCharacter2Button = new Button();
        mainCharacter2Button.setGraphic(new ImageView(new Image("mainCharacter2.png")));
        mainCharacter2Button.setOnAction(e -> System.exit(0));

        layoutPlay.getChildren().addAll(mainCharacter1Button, mainCharacter2Button);

        Scene play = new Scene(layoutPlay);
        window.setScene(play);
    }


    @Override
    public void start(Stage primaryStage) throws Exception, FileNotFoundException{

        // Window Creation
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        screenWidth = screenSize.getWidth();
        screenHeight = screenSize.getHeight();
        window = primaryStage;
        window.setTitle("Chips Clout Chase");

        // Title Image
        //FileInputStream inputStream = new FileInputStream("C:\\betterlogo.png");
        Image image = new Image("betterlogo.png");
        ImageView title = new ImageView(image);
        title.setScaleX(2.0);
        title.setScaleY(2.0);
        title.setPreserveRatio(true);

        //MainMenu Layout
        layoutMain = new GridPane();
        layoutMain.getStylesheets().add("buttons.css");
        //LeaderBoards
        VBox leaderBoardArea = new VBox();
        leaderBoardArea.setAlignment(Pos.TOP_LEFT);
        leaderBoardArea.setPadding(new Insets(20, 0, 20, 0));
        leaderBoardArea.maxWidth(300);

        lTitle = new Label("Rank");
        lTitle.setScaleX(1.25);
        lTitle.setScaleY(1.25);
        lTitle.setStyle("-fx-font-weight: bold; -fx-text-fill: #00ffff");

        GridPane leaderPane = new GridPane();
        Label rankLabel = new Label("Rank");
        rankLabel.setStyle(L_STYLE);

        Label userName = new Label("Username");
        userName.setStyle(L_STYLE);

        Label points = new Label("Points");
        points.setStyle(L_STYLE);

        leaderPane.add(rankLabel, 0, 0);
        leaderPane.add(userName, 2, 0);
        leaderPane.add(points, 4, 0);

        // Rank Labels
        lone = new Label("1. ");
        lone.setStyle(L_STYLE);
        Label lonePad = new Label( "    ");
        ltwo = new Label ("2. ");
        ltwo.setStyle(L_STYLE);
        Label ltwoPad = new Label( "    ");
        lthree = new Label("3. ");
        lthree.setStyle(L_STYLE);
        lfour = new Label("4. ");
        lfour.setStyle(L_STYLE);
        lfive = new Label("5. ");
        lfive.setStyle(L_STYLE);
        lsix = new Label("6. ");
        lsix.setStyle(L_STYLE);
        lseven = new Label("7. ");
        lseven.setStyle(L_STYLE);
        leight = new Label("8. ");
        leight.setStyle(L_STYLE);
        lnine = new Label("9. ");
        lnine.setStyle(L_STYLE);
        lten = new Label("10. ");
        lten.setStyle(L_STYLE);

        Label user1 = new Label(leaderboard.leaderboard.get(0));
        Label user2 = new Label(leaderboard.leaderboard.get(1));
        Label user3 = new Label(leaderboard.leaderboard.get(2));
        Label user4 = new Label(leaderboard.leaderboard.get(3));
        Label user5 = new Label(leaderboard.leaderboard.get(4));
        Label user6 = new Label(leaderboard.leaderboard.get(5));
        Label user7 = new Label(leaderboard.leaderboard.get(6));
        Label user8 = new Label(leaderboard.leaderboard.get(7));
        Label user9 = new Label(leaderboard.leaderboard.get(8));
        Label user10 = new Label(leaderboard.leaderboard.get(9));

        user1.setStyle(L_STYLE);
        user2.setStyle(L_STYLE);
        user3.setStyle(L_STYLE);
        user4.setStyle(L_STYLE);
        user5.setStyle(L_STYLE);
        user6.setStyle(L_STYLE);
        user7.setStyle(L_STYLE);
        user8.setStyle(L_STYLE);
        user9.setStyle(L_STYLE);
        user10.setStyle(L_STYLE);

        leaderPane.add(lone, 0, 1);
        leaderPane.add(lonePad, 1, 0);
        leaderPane.add(ltwo, 0, 2);
        leaderPane.add(ltwoPad, 3, 0);
        leaderPane.add(lthree, 0, 3);
        leaderPane.add(lfour, 0, 4);
        leaderPane.add(lfive, 0 ,5);
        leaderPane.add(lsix, 0, 6);
        leaderPane.add(lseven, 0, 7);
        leaderPane.add(leight, 0, 8);
        leaderPane.add(lnine, 0, 9);
        leaderPane.add(lten, 0, 10);
        leaderPane.add(user1, 2, 1);
        leaderPane.add(user2, 2, 2);
        leaderPane.add(user3, 2, 3);
        leaderPane.add(user4, 2, 4);
        leaderPane.add(user5, 2, 5);
        leaderPane.add(user6, 2, 6);
        leaderPane.add(user7, 2, 7);
        leaderPane.add(user8, 2, 8);
        leaderPane.add(user9, 2, 9);
        leaderPane.add(user10, 2, 10);

        leaderBoardArea.prefHeight(100);
        leaderBoardArea.getChildren().addAll(leaderPane);



        // Settings


        GridPane settingsGrid = new GridPane();

        BackgroundImage myBI= new BackgroundImage(new Image(inputStream2   ,screenWidth,screenHeight,false,true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        settingsGrid.setBackground(new Background(myBI));

        Scene settingsScene = new Scene(settingsGrid);
        //Buttons

        pad1 = new Label("");
        pad1.setPrefWidth(325);
        pad2 = new Label("");
        pad2.setPrefHeight(300);

        playButton = new Button("Play");

        playButton.setOnMouseClicked(e -> {
            try {
                play();
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
        });
        playButton.setId("retro");
        playButton.setMinWidth(200);

        settingsButton = new Button("Settings");

        settingsButton.setAlignment(Pos.CENTER);
        settingsButton.setOnAction(e -> window.setScene(settingsScene));
        settingsButton.setId("retro");
        settingsButton.setMinWidth(100);
        settingsButton.setPadding(new Insets(0,0,0,0));


        quitButton = new Button("Exit Game");

        quitButton.setId("retro");
        quitButton.setMinWidth(100);
        quitButton.setAlignment(Pos.CENTER);
        quitButton.setOnAction(e -> System.exit(0));

        tutorialButton = new Button("Tutorial");
        tutorialButton.setMinWidth(100);
        tutorialButton.setId("retro");
        tutorialButton.setAlignment(Pos.CENTER);

        newGameButton = new Button("New Game");
        newGameButton.setMinWidth(100);
        newGameButton.setAlignment(Pos.CENTER);
        newGameButton.setId("retro");

        pad3 = new Label("");
        pad3.setPrefWidth(0);

        pad4 = new Label("");
        pad4.setPrefHeight(150);

        pad5 = new Label("");
        pad5.setPrefWidth(50);


        layoutMain.add(playButton, 5, 2, 3, 1);
        layoutMain.add(newGameButton, 5, 3);
        layoutMain.add(tutorialButton, 6, 3);
        layoutMain.add(settingsButton , 5, 4);
        layoutMain.add(quitButton, 6, 4);
        layoutMain.add(pad1, 2, 1);
        layoutMain.add(title, 5, 1, 3, 1);
        layoutMain.add(pad2, 5, 1);
        layoutMain.add(pad3, 3,2);
        layoutMain.add(pad4, 5, 0);
        layoutMain.add(pad5, 0, 1, 1, 5);
        //layoutMain.add(motdBox,1,1);
        layoutMain.add(leaderBoardArea, 1, 1);


        BackgroundImage myBI2= new BackgroundImage(new Image(inputStream2   ,screenWidth,screenHeight,false,
                true),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT,
                BackgroundSize.DEFAULT);
        layoutMain.setBackground(new Background(myBI2));


        //Scene MainMenu
        mainMenu = new Scene(layoutMain, screenWidth, screenHeight);
        window.setScene(mainMenu);

        window.show();
    }


    public static void main(String[] args) {
        launch(args);
    }



}