package networkingMOTD;

import java.util.ArrayList;

public class LeaderBoard {
    public ArrayList<String> leaderboard = new ArrayList<String>();

    public LeaderBoard(){

            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");
            leaderboard.add("Dude");

    }



}