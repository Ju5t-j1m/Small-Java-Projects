class Encrypt {


    private static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    static String PlainEncrypt(String plaintext, int key) {

        String cipherText = "";
        plaintext = plaintext.toUpperCase();

        for (int i = 0; i < plaintext.length(); i++) { //for the length of the plaintext string

            int charPosition = ALPHABET.indexOf(plaintext.charAt(i)); //record position in the alphabet of i(the letter in plaintext)
            int keyVal = (key + charPosition) % 26; //shifts the char and keeps the shift in the bound 26(rollover)
            char replaceVal = ALPHABET.charAt(keyVal);
            cipherText += replaceVal; //adding shifted letter

        }

        return cipherText;
    }
}
