import java.util.Scanner;

public class Setup {


    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter text to be encrypted: ");
        String plaintext = input.nextLine();

        System.out.println("Enter the bit shift key: ");
        int key = Integer.parseInt(input.nextLine());

        input.close();


        System.out.println(
                "Plaintext: " + plaintext + "\n" + "Using a shift of: " + key + "\n\nCipher| " + Encrypt.PlainEncrypt(
                        plaintext, key) + " |");

    }

}