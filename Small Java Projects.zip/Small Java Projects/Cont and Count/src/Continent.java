import java.util.ArrayList;

public class Continent {

 public double highestPointTotal;	
 private String name;
 
 Continent(String nameParam){
	 
	 name = nameParam;
 }
 
 private void setName(String nameParam) {
		
		name = nameParam;						
		
	}
 
 public ArrayList <Country> countryList = new ArrayList<>();
 
 public void addCountry(String countryName, String pointLocation, double highestPoint) {
	 
	 Country newCountry = new Country(countryName, pointLocation, highestPoint);
	 countryList.add(newCountry);
 }
 
 public String toString() {
		String systemString = null;
		for(int i = 0; i < countryList.size(); i++) {
			
			 systemString = countryList.get(i).toString()+"\n";
		}
		return systemString;
	}
 
 

 public static void main(String[] args) {
	 Continent Europe = new Continent("Europe");
	 
	 Europe.addCountry("coun1", "g", 1.012);
	 Europe.addCountry("coun2", "f", 2.016);
	 Europe.addCountry("coun3", "e", 3.022);
	 Europe.addCountry("coun4", "d", 4.029);
	 Europe.addCountry("coun5", "c", 5.038);
	 Europe.addCountry("coun6", "b", 6.049);
	 Europe.addCountry("coun7", "a", 7.062);
 }
 
}
