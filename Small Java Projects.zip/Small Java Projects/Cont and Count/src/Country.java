
public class Country {


 private String countryName;
 private String pointLocation;
 private double highestPoint;
 
 
 public Country(String countryNameParam, String pointLocationParam, double highestPointParam){
		
		setCountryName(countryNameParam);
		setPointLocation(pointLocationParam);
		setHighestPoint(highestPointParam);
		
	 }
 
 
 private void setCountryName(String countryNameParam){
	 
	 countryName = countryNameParam;
 }
 
 private void setPointLocation(String pointLocationParam) {
	 
	 pointLocation = pointLocationParam;
 }
 
 private void setHighestPoint(double highestPointParam) {
	 
	 highestPoint = highestPointParam;
 }
 
 
 
 
 
 private String getCountryName() { 
	 
	 return countryName;
 }
 
 private String getPointLocation() {
	 
	 return pointLocation;
 }
 
 private double getHighestPoint() {
	 
	 return highestPoint;
 }
 
 
 public String toString() {
	 
 return(countryName + " highest point is in " + pointLocation + " the point reaches a height of " + highestPoint);
 
 
 }
}
