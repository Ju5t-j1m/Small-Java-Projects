public class Input {
    public static void main(String[] args) {
        
 
        
        Continent Europe = new Continent("Europe");

        
        Europe.addCountry("Trappist1b", "g", 1.012);
        Europe.addCountry("Trappist1c", "f", 2.016);
        Europe.addCountry("Trappist1d", "e", 3.022);
        Europe.addCountry("Trappist1e", "d", 4.029);
        Europe.addCountry("Trappist1f", "c", 5.038);
        Europe.addCountry("Trappist1g", "b", 6.049);
        Europe.addCountry("Trappist1h", "a", 7.062);

 }
}
