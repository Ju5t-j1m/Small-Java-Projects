
import java.util.Scanner;
import java.awt.List;
import java.util.ArrayList;
	
	class Converter {
		public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner in = new Scanner(System.in);
		
		ArrayList<Integer> Convnum = new ArrayList<Integer>();
		System.out.print("Enter the number you would like converted (please seperate every number with a space): ");
		while (in.hasNextInt()){
			Convnum.add(in.nextInt());
			}
			System.out.println(Convnum);
			int size = Convnum.size();
			
			StringBuilder sb = new StringBuilder();
			for (int i = Convnum.size() - 1; i >= 0; i--) {
			  int num = Convnum.get(i);
			  sb.append(num);
				}
			
			StringBuilder result = sb.reverse();
			if (size <= 3) {
					System.out.println("No change is needed to your number in both standards it is printed as " + (result));
					}
			
				else {
					for(int b = Convnum.size(); b >= 4;) {
						b = b-3;
						Convnum.set(b, int ',');
						System.out.println(Convnum);
					}
					
						
						StringBuilder sb1 = new StringBuilder();
							for (int i = Convnum.size() - 1; i >= 0; i--) {
								int num = Convnum.get(i);
								sb1.append(num);
							}
					
					StringBuilder resulttrue = sb1.reverse();
					System.out.println(resulttrue);
				}
		
			
	    }
		
		
	}
