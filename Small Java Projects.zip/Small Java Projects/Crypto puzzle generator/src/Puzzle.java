import javax.crypto.*;

/**
 * @Author Jimmy Norman
 * Puzzle class initialises the puzzle for each instance of (4096)
 *
 */
public class Puzzle {


    byte[] puzzle = new byte[26];// 208 bits (128 0 buffer) (16-17 puzzle number) (64 key)
    private int puzzleNum; //the unique id of each puzzle
    private SecretKey secretKey;


    /**Calls the constructor for Puzzle
     *
     * @param number puzzle identifier
     * @param key
     */
    Puzzle(int number, SecretKey key) {


        this.puzzleNum = number;
        this.secretKey = key;

        setBytePosition(); //call setup of array

    }

    /**
     * Initialise the Byte array with
     * Buffer, secret key, puzzle number
     */
    private void setBytePosition() { //setup initial location of puzzle data

        byte[] puzzleNumArray;

        puzzleNumArray = CryptoLib.smallIntToByteArray(this.puzzleNum); //convert to bytearray
        this.puzzle[16] = puzzleNumArray[0];
        this.puzzle[17] = puzzleNumArray[1]; //placing the puzzlenumber in the bytearray



        for (int i=0; i < 16; i++){
            this.puzzle[i] = 0; //Filling the first 128 bits as 0
        }

        byte[] secretKeyArray;
        secretKeyArray = this.secretKey.getEncoded();

        System.arraycopy(secretKeyArray, 0, this.puzzle, 18, 8); //placing the Encoded secret key into the byte array

    }

    //Getters---------------------------

    public int getPuzzleNumber() {

        return puzzleNum;
    }

    public SecretKey getKey() {

        return secretKey;
    }

    public byte[] getPuzzleAsBytes() {

        return puzzle;
    }

}
