import javax.crypto.*;
import java.security.*;
import java.security.spec.*;
import java.util.*;
import java.io.*;

/**
 * Create's each puzzle, encodes and places into ArrayList
 *@Author Jimmy Norman
 *
 */
public class PuzzleCreator {

    private final int NUMBER_OF_PUZZLES = 4096; //Number of sent puzzles

    SecretKey secretKey;
    private static final int MAX_SHORT = (Character.MAX_VALUE) + 1; //Upper bound (65536)
    Cipher cipher = Cipher.getInstance("DES"); //using DES as the Encryption standard
    private ArrayList<Puzzle> arrayOfPuzzles;


    PuzzleCreator() throws NoSuchPaddingException, NoSuchAlgorithmException {

    }


    /**
     * Creates an Arraylist of 4096 unique key puzzles.
     * @return Arraylist of 4096 Puzzles
     */
    public ArrayList<Puzzle> createPuzzles() {
        ArrayList<Puzzle> arrayOfPuzzle;
        arrayOfPuzzle = new ArrayList<Puzzle>();
        for (int i = 1; i <= NUMBER_OF_PUZZLES; i++) { //for each new puzzle created

            try {
                SecretKey secretKey = CryptoLib.createKey(createRandomKey()); //creating a random secretKey
                arrayOfPuzzle.add(new Puzzle(i, secretKey));
            } catch (InvalidKeySpecException  | NoSuchAlgorithmException  | InvalidKeyException e) {
                e.printStackTrace();
            }


        }
        this.arrayOfPuzzles = arrayOfPuzzle;

        return arrayOfPuzzle;
    }


    /**
     * Creates a random key of 8 Bytes
     * @return Byte array of generated Key
     */

    public byte[] createRandomKey(){
        byte[] key;

        key = new byte[8];

        Random keyRandom = new Random();
        int randomGen = keyRandom.nextInt(MAX_SHORT);

        key[0] = CryptoLib.smallIntToByteArray(randomGen)[0]; //First and second half of Bytes for key
        key[1] = CryptoLib.smallIntToByteArray(randomGen)[1];

        for(int i=2; i<8; i++){ //final 48bit zeros

            key[i] = 0;
        }

        return key;
    }

    /**
     * Encrypts the each puzzle using DES
     * @param key Generated key
     * @param puzzle each instance of 4096 puzzles

     * @return Encrypted text
     *
     * series of throws for key based exceptions
     * @throws InvalidKeySpecException
     * @throws NoSuchAlgorithmException
     * @throws InvalidKeyException
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     */

    public byte[] encryptPuzzle(byte[] key, Puzzle puzzle) throws InvalidKeySpecException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException { //should be 32 bytes
        byte[] cipherText;
        SecretKey secretKey;
        secretKey = CryptoLib.createKey(key);

        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        cipherText = cipher.doFinal(puzzle.getPuzzleAsBytes());

        return cipherText;
    }

    /**
     * All puzzle ciphertext into a bin file
     * @param filename The outputted .bin file
     */
    public void encryptPuzzlesToFile (String filename) {

        FileOutputStream outBin = null; //initialise the file
        try {
            outBin = new FileOutputStream(filename); //opened with filename
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < NUMBER_OF_PUZZLES; i++) {


            try {
                byte[] encryptText;
                encryptText = encryptPuzzle(createRandomKey(),arrayOfPuzzles.get(i)); //encrypt all puzzles creating a new key for each
                assert outBin != null;

                outBin.write(encryptText); //write to file
            } catch (InvalidKeySpecException | NoSuchAlgorithmException | InvalidKeyException | BadPaddingException | IllegalBlockSizeException | IOException e) {
                e.printStackTrace();
            }


        }
        try {
            assert outBin != null;
            outBin.close(); //empty and close

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     *
     * @param puzzleNum puzzle Identifier
     * @return the key of an identified puzzle
     */
    public SecretKey findKey(int puzzleNum){

        return arrayOfPuzzles.get(puzzleNum-1).getKey();//returning the key of the last puzzle

    }
}
