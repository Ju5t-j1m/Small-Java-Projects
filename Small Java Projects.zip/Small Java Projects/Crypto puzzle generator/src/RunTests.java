 public class RunTests {
        public static void main(String[] args_) throws Exception {
            Tests.test1();
            Tests.test2();
            Tests.test3();
            Tests.test5();
            Tests.test6();
            Tests.test9();
            Tests.test10();
            Tests.test12();
            Tests.test13();
            Tests.test15();
            Tests.test16();
            Tests.test18();
        }
    }
