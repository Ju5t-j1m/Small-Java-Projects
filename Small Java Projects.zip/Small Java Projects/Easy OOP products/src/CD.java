
public class CD extends Playable{

	protected String artist;
	
	
	public CD(double price, int numStock, double runtime, String title, String atrist) {
		super(price, numStock, runtime, title);
		
	} 
	
	
	public void setArtist(String artist) {
		this.artist = artist;
		
	}
	
	public String getDirector(String artist) {
		
		return artist;
	}
	
}
