
public class DVD extends Playable {
	protected String director;
	
	
	
	public double rentalcost() {
		
		double rent = 1.20;
		return rent;
	}
	
	public DVD(double price, int numStock, double runtime, String title, String director) {
		super(price, numStock, runtime, title);
		
	} 
	
	
	public void setDirector(String director) {
		this.director = director;
		
	}
	
	public String getDirector() {
		
		return director;
	}
	
	
}
