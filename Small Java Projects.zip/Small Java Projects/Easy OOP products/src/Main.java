
public class Main {

	public static void main (String args[]) {
		
		Playable play1 = new Playable (15.02, 10, 180, "new and playable"); Playable itself = play1;
		DVD DVD1 = new DVD (20.00, 4, 140, "Test title", "DVD testartist");Playable anotherplayable = DVD1;
		CD CD1 = new CD (10.99, 2, 200, "Hello", "Test artist");Playable newplayable = CD1;
		
		
		DVD  myDVD = new DVD (11.17 , 9, 102,"Your  Name", "Makoto  Shinkai");Playable  myPlayable = myDVD;
		
		DVD myDVD2 = new DVD (5.99, 2, 145, "Marley and Me", "Someone Jones");Playable  myPlayable2 = myDVD2;
		
		myDVD2 = (DVD) myPlayable;
		
		System.out.println(myDVD2.getDirector());
		System.out.println(((DVD) myPlayable).getDirector());
		
		System.out.println("Title: " + (myPlayable.getTitle()  +" Runtime: "+ myPlayable.getRuntime() + " Rental cost: �" + myPlayable.rentalcost()));
	}
	
}
