import java.util.Scanner;


public class Grade {
public static void main(String[] args) {
		boolean check = false;
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter your grade A - F: ");
		String a = scanner.nextLine();
		
			if (a.equals('A' || 'A+' || 'A-')) {
					check = true;
					System.out.println("Your grade is equal to a university 1st (1)");
					
				}
			
			else if (a.matches("B || B+ || B-")) {
				check = true;
				System.out.println("Your grade is equal to a university upper 2nd (2-1)");
			}
			
			else if (a.matches("C || C+ || C-")) {
				check = true;
				System.out.println("Your grade is equal to a university lower 2nd (2-2)");
			}
			
			else if (a.matches("D || D+ || D- || E || E+ || E- || F || F+ || F-")) {
				check = true;
				System.out.println("Your grade is equal to a university lower 3rd (3)");
			}
			
			else if (check = false) {
				System.out.println("Please enter a valid Grade.");
				main(args);
			}
		
		
	}
}