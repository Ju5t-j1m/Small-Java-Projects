import javax.crypto.*;
import java.util.*;

public class Start {

    public static void main(String[] args) throws Exception {

        //User input
        System.out.println("Please enter your Plaintext to encrypt");
        Scanner input = new Scanner(System.in);
        String plainText = input.nextLine();

        System.out.println("Please enter a Password(Key) to use for encryption");
        String Password = input.nextLine();
        input.close();

        //Check
        System.out.println("\nPlaintext: " + plainText + "\n");

        //2 types of Key generation
        SecretKey secretKey1 = new AES().generateKeyFromPassword(Password);
        //SecretKey secretKey2 = new AES().generateRandomKey();

        String encText1 = new AES().encrypt(plainText, secretKey1);
        //String encText2 = new AES().encrypt(plainText, secretKey2);

        //Decrypt and print
        System.out.println("Encrypted text (w/Password key): " + encText1);
        //System.out.println("Encrypted text (Using a random key): " + encText2 + "\n");

        String decText1 = new AES().decrypt(encText1, secretKey1);
        //String decText2 = new AES().decrypt(encText2, secretKey2);

        System.out.println("Decrypted text (Password key): " + decText1);
        //System.out.println("Decrypted text (Random Password): " + decText2);
    }

}
