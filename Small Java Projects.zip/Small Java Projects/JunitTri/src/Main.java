import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class Main {

	@Test
	public void case1_c_min() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 100, 1));
	}
	
	@Test
	public void case2_c_min2() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 100, 2));
	}
	
	@Test
	public void case3_c_mid1() {
		assertEquals(TriangleClassifier.TriangleType.EQUILITERAL, TriangleClassifier.classify(100, 100, 100));
	}
	
	@Test
	public void case4_c_max() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 100, 199));
	}
	
	@Test
	public void case5_c_max2() {
		assertEquals(TriangleClassifier.TriangleType.NOT_A_TRIANGLE, TriangleClassifier.classify(100, 100, 200));
	}
	
	//End of change in C tests
	
	
	
	@Test
	public void case6_b_min() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 1, 100));
	}
	
	@Test
	public void case7_b_min2() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 2, 100));
	}
	
	@Test
	public void case8_b_mid() {
			assertEquals(TriangleClassifier.TriangleType.EQUILITERAL, TriangleClassifier.classify(100, 100, 100));
		}
	
	@Test
	public void case9_b_max() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(100, 199, 100));
	}
	
	@Test
	public void case10_b_max2() {
		assertEquals(TriangleClassifier.TriangleType.NOT_A_TRIANGLE, TriangleClassifier.classify(100, 200, 100));
	}
	
	//End of change in B tests
	
	@Test
	public void case11_a_min() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(1, 100, 100));
	}
	
	@Test
	public void case12_a_min2() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(2, 100, 100));
	}
	
	@Test
	public void case13_a_mid() {
		assertEquals(TriangleClassifier.TriangleType.EQUILITERAL, TriangleClassifier.classify(100, 100, 100));
	}
	
	@Test
	public void case14_a_max() {
		assertEquals(TriangleClassifier.TriangleType.ISOSCELES, TriangleClassifier.classify(199, 100, 100));
	}
	
	@Test
	public void case15_a_max2( ) {
		assertEquals(TriangleClassifier.TriangleType.NOT_A_TRIANGLE, TriangleClassifier.classify(200, 100, 100));
	}
	
	//End of change in A tests
	
}
