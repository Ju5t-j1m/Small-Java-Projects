import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class Main {

	@Test
	public void T1() {
		assertEquals(nextDateFunction.tomorrow(14, 6, 2000), ("15.6.---2000"));
	}
	
	@Test
	public void T2() {
		assertEquals(nextDateFunction.tomorrow(14, 6, 1996), ("15.6.---1996"));
	}
	
	@Test
	public void T3() {
		assertEquals(nextDateFunction.tomorrow(14, 6, 2002), ("15.6.---2002"));
	}
	
	@Test
	public void T4() {
		assertEquals(nextDateFunction.tomorrow(29, 6, 2000), ("30.6.---2000"));
	}
	
	@Test
	public void T5() {
		assertEquals(nextDateFunction.tomorrow(29, 6, 1996), ("30.6.---1996"));
	}
	
	@Test
	public void T6() {
		assertEquals(nextDateFunction.tomorrow(29, 6, 2002), ("30.6.---2002"));
	}
	
	@Test
	public void T7() {
		assertEquals(nextDateFunction.tomorrow(30, 6, 2000), ("1.7.---2000"));
	}
	
	@Test
	public void T8() {
		assertEquals(nextDateFunction.tomorrow(30, 6, 1996), ("1.7.---1996"));
	}
	
	@Test
	public void T9() {
		assertEquals(nextDateFunction.tomorrow(30, 6, 2002), ("1.7.---2002"));
	}
	
	@Test
	public void T10() {
		assertEquals(nextDateFunction.tomorrow(31, 6, 2000), ("Invalid input date"));
	}
	
	@Test
	public void T11() {
		assertEquals(nextDateFunction.tomorrow(31, 6, 1996), ("Invalid input date"));
	}
	
	@Test
	public void T12() {
		assertEquals(nextDateFunction.tomorrow(31, 6, 2002), ("Invalid input date"));
	}
	
	@Test
	public void T13() {
		assertEquals(nextDateFunction.tomorrow(14, 7, 2000), ("15.7.---2000"));
	}
	
	@Test
	public void T14() {
		assertEquals(nextDateFunction.tomorrow(14, 7, 1996), ("15.7.---1996"));
	}
	
	@Test
	public void T15() {
		assertEquals(nextDateFunction.tomorrow(14, 7, 2002), ("15.7.---2002"));
	}
	
	@Test
	public void T16() {
		assertEquals(nextDateFunction.tomorrow(29, 7, 2000), ("30.7.---2000"));
	}
	
	@Test
	public void T17() {
		assertEquals(nextDateFunction.tomorrow(29, 7, 1996), ("30.7.---1996"));
	}
	
	@Test
	public void T18() {
		assertEquals(nextDateFunction.tomorrow(29, 7, 2002), ("30.7.---2002"));
	}
	
	@Test
	public void T19() {
		assertEquals(nextDateFunction.tomorrow(30, 7, 2000), ("31.7.---2000"));
	}
	
	@Test
	public void T20() {
		assertEquals(nextDateFunction.tomorrow(30, 7, 1996), ("31.7.---1996"));
	}
	
	@Test
	public void T21() {
		assertEquals(nextDateFunction.tomorrow(30, 7, 2002), ("31.7.---2002"));
	}
	
	@Test
	public void T22() {
		assertEquals(nextDateFunction.tomorrow(31, 7, 2000), ("1.8.---2000"));
	}
	
	@Test
	public void T23() {
		assertEquals(nextDateFunction.tomorrow(31, 7, 1996), ("1.8.---1996"));
	}
	
	@Test
	public void T24() {
		assertEquals(nextDateFunction.tomorrow(31, 7, 2002), ("1.8.---2002"));
	}
	
//Feb tests	
	
	@Test
	public void T25() {
		assertEquals(nextDateFunction.tomorrow(14, 2, 2000), ("15.2.---2000"));
	}
	
	@Test
	public void T26() {
		assertEquals(nextDateFunction.tomorrow(14, 2, 1996), ("15.2.---1996"));
	}
	
	@Test
	public void T27() {
		assertEquals(nextDateFunction.tomorrow(14, 2, 2002), ("15.2.---2002"));
	}
	
	@Test
	public void T28() {
		assertEquals(nextDateFunction.tomorrow(29, 2, 1996), ("1.3.---1996"));
	}
	
	@Test
	public void T29() {
		assertEquals(nextDateFunction.tomorrow(29, 2, 2000), ("1.3.---2000"));
	}
	
	@Test
	public void T30() {
		assertEquals(nextDateFunction.tomorrow(29, 2, 2002), ("Invalid input date"));
	}
	
	@Test
	public void T31() {
		assertEquals(nextDateFunction.tomorrow(30, 2, 2000), ("Invalid input date"));
	}
	
	@Test
	public void T32() {
		assertEquals(nextDateFunction.tomorrow(30, 2, 1996), ("Invalid input date"));
	}
	
	@Test
	public void T33() {
		assertEquals(nextDateFunction.tomorrow(30, 2, 2002), ("Invalid input date"));
	}
	
	@Test
	public void T34() {
		assertEquals(nextDateFunction.tomorrow(31, 2, 2000), ("Invalid input date"));
	}
	
	@Test
	public void T35() {
		assertEquals(nextDateFunction.tomorrow(31, 2, 1996), ("Invalid input date"));
	}
	
	@Test
	public void T36() {
		assertEquals(nextDateFunction.tomorrow(31, 2, 2002), ("Invalid input date"));
	}
	
}