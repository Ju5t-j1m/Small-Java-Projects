
import java.util.NoSuchElementException;

public class LinkedList<T> {
	private Link<T> head; 
	private Link<T> tail; 
	
	/*
	 * Create and initialise the head and tail as null
	 */
	public LinkedList(){
		tail = null;
		head = null;
	}
	

	/*
	 * Set the tail as current element 
	 */
	public void setTail() {
		Link<T> currentEle=head;
		
		while(currentEle.getNext() != null) {
			currentEle=currentEle.getNext();
		}
		tail=currentEle;
	}
	/*
	 * Simple method to check if the head is empty
	 * will allow us to exit runtime
	 */
	public boolean isEmpty() {
		if (head == null){
			return true;
		}else {
			return false;
		}
	}
	
	/*
	 * 
	 */
	public T elementAt(int i) throws NoSuchElementException{
		Link<T> currentEle=head;
		
		for(; i>0; i--) {
				if(currentEle.getNext()==null) {
					throw new NoSuchElementException();
				}
			currentEle = currentEle.getNext();				
		}
		return currentEle.getElement();

	}
	
	/*
	 * Simple method that will return the current element
	 * standard element exception used if nothing is found
	 */
	public Link<T> getLink(int i) throws NoSuchElementException{
		Link<T> currentEle = head;
		
		for(; i>0; i--) {
			if (currentEle.getNext()==null) {
				throw new NoSuchElementException();
			}
			currentEle = currentEle.getNext();
		}
		return currentEle;
	}
	
	/*
	 * will allow us to insert a new link to element
	 * several statements are for cases: empty and zero, just zero, not the tail element but -1
	 * 
	 */
	
	public void insertAt(int i, T e)throws NoSuchElementException {
		
		if (this.isEmpty() && i==0) {
			
			head= new Link<T>();
			head.setElement(e);
			
			}else if(i==0) {
				Link<T> newLink = new Link<T>();
			
				newLink.setElement(e);
				
				newLink.setNext(head);
				head=newLink;
			
			}else if(this.getLink(i-1) != tail){
				Link<T> newLink = new Link<T>();
			
				newLink.setElement(e);
				newLink.setNext(this.getLink(i-1).getNext());
				this.getLink(i-1).setNext(newLink);
		}else {
			Link<T> newLink = new Link<T>();
			
			newLink.setElement(e);
			this.getLink(i-1).setNext(newLink);
		}
		
		setTail();
	}
	
}

