
public class run {

	public static void main(String[] args) {
		LinkedList<String> testlist = new LinkedList<String>() ;
	
		
		LinkedList<Integer> testlist2 = new LinkedList<Integer>() ;
		
		testlist2.insertAt(0, 0);
		testlist2.insertAt(1, 1);
		
		System.out.println(testlist2.elementAt(1));
		
		
		
		testlist.insertAt(0, "test");
		testlist.insertAt(1, "string");
		
		System.out.println(testlist.elementAt(0)+" "+ testlist.elementAt(1));
		
		System.out.println("\n");
		
		testlist.insertAt(1, "linked");
		
		System.out.println(testlist.elementAt(2)+" "+ testlist.elementAt(1));
		
		
	}

}
