
public class fib {
	
	public static int fibcalc(int fib) {
		
	     if (fib == 0) {
	        return 0;
	        
	    }else if (fib ==1) {
	    	return 1;
	    	
	    }else if (fib >= 2){
	    	int fib1 =  fibcalc(fib - 1); 
	    	int fib2 =  fibcalc(fib - 2);
	    	return (fib1 +fib2);
	    	
	    }
	     
		return fib;
	}
	

	public static void main (String args[]) {
		int result = fibcalc(6);
		System.out.println(result);
		
	}
}