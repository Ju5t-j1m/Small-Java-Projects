
public class mult {
	
	public static int multtwo(int n, int m) {
		
		if (n==0 || m==0) {
			return 0;
		}
		else {
	        int total = multtwo(n, m - 1) + n;
	        return total;
	    }
	    
	}
	

	public static void main (String args[]) {
		int result = multtwo(4,4);
		System.out.println(result);
		
	}
}