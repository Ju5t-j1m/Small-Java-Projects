
public class BST {

private BSTNode root;

	
	/*
	 * Setters and getters for the root node (Top of the tree)
	 */
	public void setRoot(BSTNode root) {
		this.root = root;
		
	}
	
	public BSTNode getRoot() {
		
		return root;
	}
	
	public BST (BSTNode root) {
		this.root = root;
		
	}
	
	public BST () {
		this.root = null;
		
	}
	
	/*
	 * Insert into binary tree
	 */
	
	void InsertProfile(Profile p) {
		
		BSTNode newNode = new BSTNode(p);     
		
		if (root == null) {         //covers the case of an empty tree
			
			root = newNode;
			}else {
				recursive(newNode, root);
			}
		
	}
	
	/*
	 * Recursive methods for working left and right down the tree
	 */
	private  void recursive (BSTNode p, BSTNode pointer) {
		
		//Pushing to the left
		if (pointer.getData().getSName().compareToIgnoreCase(p.getData().getSName()) >= 0) {
			if (pointer.getL() == null ){
				pointer.setL(p);
				return;
			}else {
				recursive(p, pointer.getL());
			}
			
		}
		
		//Pushing to the right
		if(pointer.getData().getSName().compareToIgnoreCase(p.getData().getSName()) < 0) {
			if (pointer.getR() == null ){
				pointer.setR(p);
				return;
		}else {
			recursive(p, pointer.getR());
		}
	
	}
	
	
	
	
 }
}
