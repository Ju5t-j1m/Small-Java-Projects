
public class BSTNode {
	
	
	private Profile data; /*data is initialised to be used for setting*/

	/*
	 * initialise nodes to the right and left
	 */
	private BSTNode l; 
	private BSTNode r;
	
	
	/*
	 * Node constructor to ensure that pointers are equal to null
	 * and that profile has data
	 */
	
	public BSTNode(Profile data){
		l = null;
		r = null;
		this.data = data;
	}
	
	/*
	 * Setters and getters for the left and right nodes
	 * as well as data
	 */
	
	public void setR(BSTNode r) {
		this.r = r;
		
	}
	
	public BSTNode getR() {
		
		return r;
	}
	
	public void setL(BSTNode l) {
		this.l = l;
		
	}
	
	public BSTNode getL() {
		
		return l;
	}

	public Profile getData() {

		return data;
	}
	
	public void setData(Profile data) {
		
		this.data = data;
	}
}
