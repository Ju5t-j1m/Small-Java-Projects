
public class BSTNodeMain {
	
	
	public static void main(String[] args) {
		
		Profile mine = new Profile("Norman", "Jim", "Welsh", "testemail@123.com" ,"bikes", "cars", "computers", "sports" , 26, 4, 2000, "Cardiff", "Wales");
		Profile new2 = new Profile("morman", "Jim", "Welsh", "testemail@123.com" ,"bikes", "cars", "computers", "sports" , 26, 4, 2000, "Cardiff", "Wales");
		
	
		BST test = new BST();
		
		test.InsertProfile(mine);
		test.InsertProfile(new2);
		
		System.out.println(test.getRoot().getData().toString());

		
		
		
		
	}





	
	
}
