
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReader {

	
	public static BST readProfileSet (String filename) {
		
			Scanner in = null;
			File file = new File("Users");
			try {
		    in = new Scanner(file); 
		   		
		    
		    String line = in.nextLine();         
		    String[] UserData = line.split(" ");
		    
		    String LastName = UserData[0];
		    String FirstName = UserData[1];
		    String Nationality = UserData[2];
		    String Email = UserData[3];
		    String Interests1 = UserData[4];
		    String Interests2 = UserData[5];
		    String Interests3 = UserData[6];
		    String Interests4 = UserData[7];
		    
	            }
	         catch(FileNotFoundException e) {
				System.out.println("File could not be found, and or parsed. Shutting down");
	        	 System.exit(0);
			
		
		return null;
	}
			return null;
	
	
	}
	
    
    
    
}