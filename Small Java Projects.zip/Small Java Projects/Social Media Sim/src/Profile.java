import java.util.ArrayList;

public class Profile {
	/*
	 * Strings storing Personal info 
	 */
	
	private String LastName;
	private String FirstName;
	private String Nationality;
	private String Email;
	
	/*
	 * Strings for interests
	 */
	
	private String Interest1;
	private String Interest2;
	private String Interest3;
	private String Interest4;
	private String Interests[] = new String[] {Interest1, Interest2, Interest3, Interest4};
	
	private int DOB_Day;
	private int DOB_Month;
	private int DOB_Year;
	
	
	private String Town;
	private String Country;
	
	public ArrayList<Profile> FriendsList;
	
	/*
	 * Constructor for each profile (Creating a new Friends list)
	 */
	
	public Profile(String LastName, String FirstName, String Nationality, String Email, String Interest1, String Interest2, String Interest3, String Interest4, int DOB_Day, int DOB_Month, int DOB_Year, String Town, String Country) {
		
		new ArrayList<Profile>();
		this.FirstName = FirstName;
		this.LastName = LastName;
		this.Nationality = Nationality;
		this.Email = Email;
		this.Interests[0] = Interest1;
		this.Interests[1] = Interest2;
		this.Interests[2] = Interest3;
		this.Interests[3] = Interest4;
		this.DOB_Day = DOB_Day;
		this.DOB_Month = DOB_Month;
		this.DOB_Year = DOB_Year;
		
	}
	
	
	
	
	//Getters and setters for some variables 
	//###// town
	
	public String getTown() {
		
		return Town;
	}
	
	public void setTown(String Town) {
		
		this.Town = Town;
	}
	
	//##// country
	
	public String getCountry() {
		
		return Country;
	}
	
	public void setCountry(String Country) {
		
		this.Country = Country;
	}
	
	//##// Nationality
	
	public String getNationality() {
		
		return Nationality;
	}
	
	public void setNationality(String Nationality) {
		
		this.Nationality = Nationality;
	}
	
	//##// Interests
	
	public String[] getInterests() {
		
		return Interests;
	}
	
	public void setInterests(String[] Interests) {
		this.Interests = Interests;
	}
	
	//##// DOB
	
	public int getDOB_Day() {
		
		return DOB_Day;
	}
	
	public int getDOB_Month() {
		
		return DOB_Month;
	}
	
	public int getDOB_Year() {
		
		return DOB_Year;
	}
	//(Compiled DOB)
	public String getDateOfBirth() {	
		
		String DOB = (DOB_Day + "/" + DOB_Month + "/" + DOB_Year);
		return DOB;
		
	}
	//##//Name
	
    public String getFname() {
		
		return FirstName;
	}
	
	public void setFirstName(String FirstName) {
		
		this.FirstName = FirstName;
	}
	
	public String getSName() {
		
		return LastName;
	}
	
	public void setSName(String LastName) {
		
		this.LastName = LastName;
	}
	
	public String getFullName(String FirstName, String LastName) {
		
		String FullName = (LastName + " " + FirstName);
		return FullName;
		
	}
	
	/*
	 * Three methods to interact with FriendsList
	 */
	void addFriend (Profile p) {

		this.addFriend(p);
		
	}
	
	Profile getFriend (int i) {
		return this.getFriend(i);

	}
	
	int numOfFriends () {
		
		return FriendsList.size();
	}
	
	//##ToString Test##//
	public String toString ( ) {
		return ("FName of the user " + this.FirstName +
				" LName of the user " + this.LastName +
				" Nationality of the user " + this.Nationality +
				" Email of the user " + this.Email + 
				" Interests of the user " + this.Interests[0] +" " + this.Interests[1] + " " + this.Interests[2] + " " + this.Interests[3] + " " + 
				" Date of Birth of user (Day) " + this.DOB_Day +
				" Date of Birth of user (Month) " + this.DOB_Month +
				" Date of Birth of user (Year) " + this.DOB_Year);
	}
	
}
