
public class ProfileMain {

	
	public static void main (String[] args) {
		
		/*
		 * Simple Test to confirm profile is functioning for given variables-..
		 * ,in my constructor
		 */
		
		Profile mine = new Profile("Norman", "Jim", "Welsh", "testemail@123.com" ,"bikes", "cars", "computers", "sports" , 26, 4, 2000, "Cardiff", "Wales");
		
		System.out.println(mine);
	}
	
}
