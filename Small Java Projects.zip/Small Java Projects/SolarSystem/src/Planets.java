
public class Planets { //planets is my second class and contains the nescacerry data and methods for adding the details to the planets
	
	private final String AU_FROM_STAR = "AU from its star, and orbits in ";
	private final String HABITABLE_STRING = " years: could be habitable? ";
	
	
	private String hYN;
	private String planetName;
	private double planetMass;  //private doubles and strings created to store the values from Autotest
	private double planetDistance;
	

	private double orbitalPeriod;
								//Boolean and orbital period stored below for readability
	private boolean habitable;
		
	Planets(String namePlanetParam, double massParam, double distanceParam){
		
		setPlanetName(namePlanetParam);
		setPlanetMass(massParam);					//Planet constructor is created to pass and set the parametres of the methods
		setPlanetDistance(distanceParam);
		setOrbitalPeriod();
		
	 }
		
		public void setPlanetName(String namePlanetParam) {
		//first set methods used to set the planets name
			planetName = namePlanetParam;
		
		 }
		 
		public void setPlanetMass(double massParam) {
		// and the mass
			planetMass = massParam;
			
			 }
		public void setPlanetDistance(double distanceParam) {
		//Distance (will later be used for calcualtion)
			planetDistance = distanceParam;
			
			 }
	
		public void setOrbitalPeriod() {
			//equation given through coursework pdf used to determine the orbital period
			orbitalPeriod = Math.sqrt(planetDistance*planetDistance*planetDistance);
			
		}
		
		public void isHabitable(double luminosity) {	//equation to determine if a planet is potentially habitable
			
			if ((planetMass < 0.6 || planetMass > 7.0)) {
														// if the mass is wrong it is not habitable
				habitable = false;
				
			}else if (planetDistance > 2.0 *Math.sqrt(luminosity)) {
														//also checks for the luminosity which is called
				habitable = false;
			}else if ((planetDistance < 0.75 * Math.sqrt(luminosity))){
				
				habitable = false;
			}else
				habitable = true; //if none of the fail conditions are met then it is potentially habitable
			}
		
		
		//Set of methods used to get the values of what has been set in them
		private double getPlanetMass() {
	
			return planetMass;
		}
		
		private String getPlanetName() {
			
			return planetName;
		}
		
		private double getPlanetDistance() {
												//This has been done for each variable 
			
			return planetDistance;
		}
		
		private double getOrbitalPeriod() {

			
			return orbitalPeriod;
		}
		
		private boolean getHabitable() {
			
			return habitable;
		}	
			
		
		public String toString() {
			if (habitable == true){  // short expression to convert a boolean into yes or no
				hYN = "yes";
			}else {
				hYN = "no";
			}
			
			double orbitRound = Math.round(orbitalPeriod*1000.0)/1000.0; // used to round the orbital period to a acceptable figure, done by adding decimal palces through multiplication and division
			
			//Completed string to return the information
			return("Planet " + planetName + " has a mass of " + planetMass + " Earths, is " + planetDistance + AU_FROM_STAR + orbitRound + HABITABLE_STRING + hYN);
		}
		
}

