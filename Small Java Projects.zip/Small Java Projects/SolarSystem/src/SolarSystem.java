import java.util.ArrayList; //i have used the array list library to create a list of planets

public class SolarSystem { //my main class is called solar system

	private String name;
	private double luminosity;  //two variables associated with my solar system
	
	public ArrayList <Planets> planetList = new ArrayList<>(); //created an arraylist for my planets
	
	
	
	 SolarSystem(String nameParam, double luminosityParam){	//Constructor created for my solar system
		 name = nameParam;
		 luminosity = luminosityParam;
	 }
	
	private void setName(String nameParam) {
		
		name = nameParam;						//name paremeter is used here to set the name of my solarsystem
		
	}
	
	private void setLuminosity(double luminosityParam) { //similarly for my luminosity
		
		luminosity = luminosityParam;
	}
	
	
	
	public void addPlanet(String planetName, double planetMass, double planetDistance) {
		//creates a new planet and will add these variables to the arraylist
		Planets newPlanet = new Planets(planetName, planetMass, planetDistance);
		newPlanet.isHabitable(luminosity);
		planetList.add(newPlanet);// adds a new planet to my arraylist
		
	}
	
	public String toString() {
		String systemString = name+"\n"; //string to string also prints the name of the system
		for(int i = 0; i < planetList.size(); i++) {
			
			 systemString += planetList.get(i).toString()+"\n"; //this is the for loop to itterate through the arraylist
		}
		return systemString; //this is then returned to later be pinted for each itteration
	}

	
}
